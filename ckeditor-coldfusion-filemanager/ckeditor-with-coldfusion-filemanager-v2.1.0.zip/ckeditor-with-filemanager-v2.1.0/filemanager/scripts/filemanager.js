/*---------------------------------------------------------
  Setup, Layout, and Status Functions
---------------------------------------------------------*/

var clickFileAfterLoad;

// Sets paths to connectors based on language selection.
var treeConnector = 'scripts/jquery_filetree/connectors/jqueryFileTree.' + lang;
var fileConnector = 'connectors/' + lang + '/filemanager.' + lang;

// Options for alert, prompt, and confirm dialogues.
$.SetImpromptuDefaults({
	overlayspeed: 'fast',
	show: 'fadeIn',
	opacity: 0.4
});

// Forces columns to fill the layout vertically.
// Called on initial page load and on resize.
var setDimensions = function(){
	var newH = $(window).height() - 50;	
	$('#splitter, #filetree, #fileinfo, .vsplitbar').height(newH);
}

// Sets the folder status, upload, and new folder functions 
// to the path specified. Called on initial page load and 
// whenever a new directory is selected.
var setUploader = function(path)
{
	$('#currentpath').val(path);
	// shorten the path, if it's longer then 450 pixels. Taking 9px per letter, that's 450/9 = 50 characters
	// The title 'Current folder: ' is 15 characters, so we've got 35 characters left.
	var tmp = path.replace(/^(.{14}).+(.{19})$/, "$1<span style='color:Gray'>...</span>$2");
	$('#uploader h1').html('Current Folder: ' + tmp);

	$('#newfolder').unbind().click(function(){
		// var foldername = prompt('Enter the name of the new folder:', 'My Folder');
		var foldername = 'My Folder';
		var msg = 'Enter the name of the new folder: <input id="fname" name="fname" type="text" value="' + foldername + '" />';
		
		var getFolderName = function(v, m){
			if(v != 1) return false;		
			var fname = m.children('#fname').val();		

			if(fname != ''){
				foldername = fname;

				$.getJSON(fileConnector + '?mode=addfolder&path=' + $('#currentpath').val() + '&name=' + foldername, function(result){
					if(result['Code'] == 0)
					{
						addFolder(result['Parent'], result['Name']);
						getFolderInfo(result['Parent']);
					} else {
						$.prompt(result['Error']);
					}				
				});
			} else {
				$.prompt('No folder name was provided.');
			}
		}
		
		$.prompt(msg, {
			callback: getFolderName,
			buttons: { 'Create Folder': 1, 'Cancel': 0 }
		});		
	});	
}

// Binds specific actions to the toolbar in detail views.
// Called when detail views are loaded.
var bindToolbar = function(data){
	// this little bit is purely cosmetic
	$('#fileinfo').find('button').wrapInner('<span></span>');

	$('#fileinfo').find('button#select').click(function(){
		selectItem(data);
	});
	
	$('#fileinfo').find('button#rename').click(function(){
		var newName = renameItem(data);
		if(newName.length) $('#fileinfo > h1').text(newName);
	});

	$('#fileinfo').find('button#delete').click(function(){
		deleteItem(data, function(){$('#fileinfo').empty().html('<h1>Select an item from the left.</h1>')});
	});
	
	$('#fileinfo').find('button#download').click(function(){
		if (data["File Type"] != 'dir')
			window.location = fileConnector + '?mode=download&path=' + data['Path'];
	});
}

// Converts bytes to kb, mb, or gb as needed for display.
var formatBytes = function(bytes){
	if (isNaN(bytes)) return "";
	var n = parseFloat(bytes);
	var d = parseFloat(1024);
	var c = 0;
	var u = [' bytes','kb','mb','gb'];
	
	while(true){
		if(n < d){
			n = Math.round(n * 100) / 100;
			return n + u[c];
		} else {
			n /= d;
			c += 1;
		}
	}
}

// function to retrieve GET params
$.urlParam = function(name){
	var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(window.location.href);
	return (results && results.length) ? results[1] : false;
}


/*---------------------------------------------------------
  Item Actions
---------------------------------------------------------*/

// Calls the SetUrl function for FCKEditor compatibility,
// passes file path, dimensions, and alt text back to the
// opening window. Triggered by clicking the "Select" 
// button in detail views or choosing the "Select"
// contextual menu option in list views. 
// NOTE: closes the window when finished.
var selectItem = function(data){
	if(window.opener){
		if($.urlParam('CKEditor')){
			// use CKEditor 3.0 integration method
			window.opener.CKEDITOR.tools.callFunction($.urlParam('CKEditorFuncNum'), data['Path']);
		} else {
			// use FCKEditor 2.0 integration method
			if(data['Properties']['Width'] != ''){
				var p = data['Path'];
				var w = data['Properties']['Width'];
				var h = data['Properties']['Height'];			
				window.opener.SetUrl(p,w,h);
			} else {
				window.opener.SetUrl(data['Path']);
			}		
		}

		window.close();
	} else {
		$.prompt('The "Select" function is only used for integration with FCKEditor.');
	}
}

// Renames the current item and returns the new name.
// Called by clicking the "Rename" button in detail views
// or choosing the "Rename" contextual menu option in 
// list views.
var renameItem = function(data){
	var finalName = '';
	var msg = 'Enter a new name for the file: <input id="rname" name="rname" type="text" value="' + data['Filename'] + '" />';

	var getNewName = function(v, m){
		if(v != 1) return false;
		rname = m.children('#rname').val();
		
		if(rname != ''){
			var givenName = rname;	
			var oldPath = data['VisiblePath'];	
			var connectString = fileConnector + '?mode=rename&old=' + data['Path'] + '&new=' + givenName;
		
			$.ajax({
				type: 'GET',
				url: connectString,
				dataType: 'json',
				async: false,
				success: function(result){
					if(result['Code'] == 0){
						var newPath = result['New Path'];
						var newName = result['New Name'];
	
						updateNode(oldPath, newPath, newName);
						if ($('#fileinfo #preview h1').length)
						{
							getFileInfo(newPath);
						} else if($('#fileinfo').data('view') == 'grid')
						{
							var $img = $('#fileinfo img[alt="' + oldPath + '"]');
							$img.parents('li').find('p:first').text(newName);
							$img.attr('alt', newPath);
						} else
						{
							$('#fileinfo td[title="' + oldPath + '"]').text(newName);
							$('#fileinfo td[title="' + oldPath + '"]').attr('title', newPath);
						}
						
						//$.prompt('Rename successful.');
					} else {
						$.prompt(result['Error']);
					}
					
					finalName = result['New Name'];		
				}
			});	
		}
	}
	
	$.prompt(msg, {
		callback: getNewName,
		buttons: { 'Rename': 1, 'Cancel': 0 }
	});
	
	return finalName;
}

// Prompts for confirmation, then deletes the current item.
// Called by clicking the "Delete" button in detail views
// or choosing the "Delete contextual menu item in list views.
var deleteItem = function(data, successFunction)
{
	var isFile = data.Path.match(/\.[^\/]+$/);
	var msg = 'Are you sure you wish to delete this '+(isFile ? 'file':'directory')+'?';
	
	var doDelete = function(v, m){
		if(v != 1) return false;	
		var connectString = fileConnector + '?mode=delete&path=' + data['Path'];

		$.ajax({
			type: 'GET',
			url: connectString,
			dataType: 'json',
			async: false,
			success: function(result){
				if(result['Code'] == 0){
					removeNode(result['Path']);
					removeNode(result['Path'].replace(/([^/\\]+)$/, "thumbs/$1")); // "
					successFunction();
					$.prompt('Delete successful.');
				} else {
					$.prompt(result['Error']);
				}			
			}
		});	
	}
	
	$.prompt(msg, {
		callback: doDelete,
		buttons: { 'Yes': 1, 'No': 0 }
	});
}





/*---------------------------------------------------------
  Functions to Update the File Tree
---------------------------------------------------------*/

// Adds a new node as the first item beneath the specified
// parent node. Called after a successful file upload.
var addNode = function(path, name)
{
	// if this var is set, then the given path is clicked() on if it appears in the next fileTree load
	clickFileAfterLoad = path + name;
	var thisNode = $('#filetree').find('a[rel="' + path + '"]');
	if (thisNode.length)
	{
		if (thisNode.parent().hasClass('expanded'))
			thisNode.click().click()
		else
			thisNode.click();
	} else
	{
		reloadFiletree();
		$('#fileinfo').html('');
		// $('#filetree').find('a[rel="' + path + name + '"]').click();
	}
		
	// new Paul Klinkenberg, 28/02/2010: empty the upload field on succesfull upload
	$('#newfile').val('');
	
	$.prompt('New file added successfully.');
}

// Updates the specified node with a new name. Called after
// a successful rename operation.
var updateNode = function(oldPath, newPath, newName)
{
	var thisNode = $('#filetree').find('a[rel="' + oldPath + '"]');
	var thisLiNode = thisNode.parent();
	thisNode.attr('rel', newPath).text(newName);
	if (thisLiNode.hasClass('directory'))
	{
		if (thisLiNode.hasClass('expanded'))
			thisNode.click().click()
		else
			thisNode.click();
	} else
	{
		var parentNode = thisLiNode.parent('li').find('a:first');
		if (parentNode.parent().hasClass('expanded'))
			parentNode.click().click()
		else
			parentNode.click();
	}
}

// Removes the specified node. Called after a successful 
// delete operation.
var removeNode = function(path){
	$('#filetree a[rel*="' + path + '"]')
	.parents('li:eq(0)')
	.fadeOut('slow', function(){ 
		$(this).remove();
	});

	$('img[src*="' + path + '"]')
	.parents('li:eq(0)')
	.fadeOut('slow', function(){ 
		$(this).remove();
	});

	$('td[title*="' + path + '"]')
	.parents('li:eq(0)')
	.fadeOut('slow', function(){ 
		$(this).remove();
	});
}

// Adds a new folder as the first item beneath the
// specified parent node. Called after a new folder is
// successfully created.
var addFolder = function(parent, name){
	var parentNode = $('#filetree').find('a[rel="' + parent + '"]');

	if(parentNode.length)
	{
		if (parentNode.parent().hasClass('expanded'))
			parentNode.click().click()
		else
			parentNode.click();
	} else {
		reloadFiletree();
		$('#fileinfo').html('');
	}
//	$.prompt('New folder added successfully.');
}




/*---------------------------------------------------------
  Functions to Retrieve File and Folder Details
---------------------------------------------------------*/

// Decides whether to retrieve file or folder info based on
// the path provided.
var getDetailView = function(path){
	if(path.lastIndexOf('/') == path.length - 1){
		getFolderInfo(path);
		$('#filetree').find('a[rel="' + path + '"]').click();
	} else {
		getFileInfo(path);
	}
}

// Binds contextual menus to items in list and grid views.
var setMenus = function(action, path){
	if (action=='select' && path.match(/\/$/))
	{
		$('#filetree').find('a[rel="' + path + '"]').click();
		return;
	}
	$.getJSON(fileConnector + '?mode=getinfo&path=' + path, function(data){
		if (data['Code'] == 0)
		{
			switch(action){
				case 'select':
					selectItem(data);
					break;
				
				case 'download':
					if (data["File Type"] != 'dir')
						window.location = fileConnector + '?mode=download&path=' + data['Path'];
					break;
					
				case 'rename':
					var newName = renameItem(data);
					break;
					
				case 'delete':
					deleteItem(data, function(){ void(0) });
					break;
			}
		} else
		{
			$.prompt(data['Error']);
		}
	});
}

// Retrieves information about the specified file as a JSON
// object and uses that data to populate a template for
// detail views. Binds the toolbar for that detail view to
// enable specific actions. Called whenever an item is
// clicked in the file tree or list views.
var getFileInfo = function(file)
{
	// Update location for status, upload, & new folder functions.
	var currentpath = file.substr(0, file.lastIndexOf('/') + 1);
	setUploader(currentpath);
	
	// Retrieve the data & populate the template.
	$.getJSON(fileConnector + '?mode=getinfo&path=' + file, function(data){
		if(data['Code'] == 0){
			var properties = '';
			var imgsize = '';
			var pr = data['Properties'];
			if(pr['Width'] && pr['Width'] != '')
			{
				// resize preview image if too large
				if (pr['Width'] > pr['Height'])
				{
					if (pr['Width'] > 350)
						imgsize = ' style="width:350px"';
				} else
				{
					if (pr['Height'] > 350)
						imgsize = ' style="height:350px"';
				}
				properties += '<dt>Dimensions</dt><dd>' + pr['Width'] + 'x' + pr['Height'] + '</dd>';
			}
			if(pr['Date Created'] && pr['Date Created'] != '') properties += '<dt>Created</dt><dd>' + pr['Date Created'] + '</dd>';
			if(pr['Date Modified'] && pr['Date Modified'] != '') properties += '<dt>Modified</dt><dd>' + pr['Date Modified'] + '</dd>';
			if(pr['Size'] && pr['Size'] != '') properties += '<dt>Size</dt><dd>' + formatBytes(pr['Size']) + '</dd>';
			
			// Include the template.
			var template = '<div id="preview"><img src="'+data['Preview']+'"'+imgsize+' />' +
				'<h1>'+data['Filename']+'</h1><dl>'+properties+'</dl></div>' +
				'<form id="toolbar">' +
				  '<button id="select" name="select" type="button" value="Select">Select</button>' +
				  '<button id="download" name="download" type="button" value="Download">Download</button>' +
				  '<button id="rename" name="rename" type="button" value="Rename">Rename</button>' +
				  '<button id="delete" name="delete" type="button" value="Delete">Delete</button>' +
				'</form>';
			
			$('#fileinfo').html(template);
			
			// Bind toolbar functions.
			bindToolbar(data);
		} else {
			$.prompt(data['Error']);
		}
	});	
}

// Retrieves data for all items within the given folder and
// creates a list view. Binds contextual menu options.
// TODO: consider stylesheet switching to switch between grid
// and list views with sorting options.
var getFolderInfo = function(path){
	// Update location for status, upload, & new folder functions.
	setUploader(path);

	// Display an activity indicator.
	$('#fileinfo').html('<img id="activity" src="images/wait30trans.gif" width="30" height="30" />');

	// Retrieve the data and generate the markup.
	$.getJSON(fileConnector + '?path=' + path + '&mode=getfolder&showThumbs=' + showThumbs, function(data){		
		var result = '';
	
		if(data){
			if(data['Code'] && data['Code'] != 0)
			{
				result = "<div style='text-align:center;color:red;'>An error occured:<br \/>" + data['Error'] + "<\/div>";
				// $.prompt(data['Error']);
			} else
			{
				var key = '';
				if($('#fileinfo').data('view') == 'grid'){
					result += '<ul id="contents" class="grid">';
					
					for(key in data){
						var props = data[key]['Properties'];
						if (props)
						{
							var scaledWidth = 64;
							var actualWidth = props['Width'];
							if(actualWidth > 1 && actualWidth < scaledWidth) scaledWidth = actualWidth;
						
							result += '<li class="' + (data[key]["File Type"] == 'dir' ? 'directory':'file') + '">'+
							 '<div class="clip"><img src="' + data[key]['Preview'] + '" width="' + scaledWidth + '" alt="' + data[key]['VisiblePath'] + '" /></div><p>' + data[key]['Filename'] + '</p>';
							if(props['Width'] && props['Width'] != '') result += '<span class="meta dimensions">' + props['Width'] + 'x' + props['Height'] + '</span>';
							if(props['Size'] && props['Size'] != '') result += '<span class="meta size">' + props['Size'] + '</span>';
							if(props['Date Created'] && props['Date Created'] != '') result += '<span class="meta created">' + props['Date Created'] + '</span>';
							if(props['Date Modified'] && props['Date Modified'] != '') result += '<span class="meta modified">' + props['Date Modified'] + '</span>';
							result += '</li>';
						}
					}
					result += '</ul>';
					if (key=='')
					{
						result = '<div style="margin-top:40px;text-align:center;"><em>No files found</em></div>';
					}
				} else {
					result += '<table id="contents" class="list">';
					result += '<thead><tr><th class="headerSortDown"><span>Name</span></th><th><span>Dimensions</span></th><th><span>Size</span></th><th><span>Modified</span></th></tr></thead>';
					result += '<tbody>';
					
					for(key in data){
						var path = data[key]['VisiblePath'];
						var props = data[key]['Properties'];
						if (props)
						{
							result += '<tr class="' + (data[key]["File Type"] == 'dir' ? 'directory':'file') + '">';
							result += '<td title="' + path + '">' + data[key]['Filename'] + '</td>';
		
							if(props['Width'] && props['Width'] != ''){
								result += ('<td>' + props['Width'] + 'x' + props['Height'] + '</td>');
							} else {
								result += '<td></td>';
							}
							
							if(props['Size'] && props['Size'] != ''){
								result += '<td><abbr title="' + props['Size'] + '">' + formatBytes(props['Size']) + '</abbr></td>';
							} else {
								result += '<td></td>';
							}
							
							if(props['Date Modified'] && props['Date Modified'] != ''){
								result += '<td>' + props['Date Modified'] + '</td>';
							} else {
								result += '<td></td>';
							}
						
							result += '</tr>';
						}
					}
					if (key=='')
					{
						result += '<tr><td colspan="4" style="text-align:center"><em>No files found</em></td></tr>';
					}
					
					result += '</tbody>';
					result += '</table>';
				}
			}
		} else {
			result += '<h1>Could not retrieve folder contents.</h1>';
		}
		
		// Add the new markup to the DOM.
		$('#fileinfo').html(result);
		
		// Bind click events to create detail views and add
		// contextual menu options.
		if($('#fileinfo').data('view') == 'grid'){
			$('#fileinfo').find('#contents li').click(function(){
				var path = $(this).find('img').attr('alt');
				getDetailView(path);
			}).each(function(){
				var $this = $(this);
				$this.contextMenu(
					{ menu: ($this.hasClass('directory') ? 'dirItemOptions':'itemOptions') }
					, function(action, el, pos){
						var path = $(el).find('img').attr('alt');
						setMenus(action, path);
					}
				)
			});
			// show new/renamed file?
			if (clickFileAfterLoad)
			{
				var tmp = $('#fileinfo img[alt="'+clickFileAfterLoad+'"]');
				if (tmp.length)
				{
					//tmp.parent('li').css('backgroundColor', 'red');
					tmp.get(0).scrollIntoView();
					clickFileAfterLoad=null;
				};
			}
		} else {
			$('#fileinfo').find('td:first-child').each(function(){
				var path = $(this).attr('title');
				var treenode = $('#filetree').find('a[rel="' + path + '"]').parent();
				$(this).css('background-image', treenode.css('background-image'));
			});
			
			$('#fileinfo tbody tr').click(function(){
				var path = $('td:first-child', this).attr('title');
				getDetailView(path);		
			}).each(function(){
				var $this = $(this);
				$this.contextMenu(
					{ menu: ($this.hasClass('directory') ? 'dirItemOptions':'itemOptions') }
					, function(action, el, pos){
						var path = $('td:first-child', el).attr('title');
						setMenus(action, path);
					}
				)
			});
			
			$('#fileinfo').find('table').tablesorter({
				textExtraction: function(node){					
					if($(node).find('abbr').size()){
						return $(node).find('abbr').attr('title');
					} else {					
						return node.innerHTML;
					}
				}
			});
			// show new/renamed file?
			if (clickFileAfterLoad)
			{
				var tmp = $('#fileinfo td[title="'+clickFileAfterLoad+'"]');
				if (tmp.length)
				{
					tmp.parent('tr').css('backgroundColor', 'red');
					tmp.get(0).scrollIntoView();
					clickFileAfterLoad=null;
				};
			}
		}
	});
}


function setFileTreeEvents()
{
	$('#filetree').find('li a:not(.context)')
	.addClass('context')
	.each(function(){
		var $this = $(this);
		$this.contextMenu(
			{ menu: ($this.parent().hasClass('directory') ? 'dirItemOptions':'itemOptions') }
			, function(action, el, pos){
				var path = $(el).attr('rel');
				setMenus(action, path);
			}
		)
	});
}


/*---------------------------------------------------------
  Initialization
---------------------------------------------------------*/

$(function(){
	// new Paul Klinkenberg 28/02/2010: check if url-var 'currentpath' is given. If so, then change the fileRoot
	if($.urlParam('currentFolder'))
		fileRoot = $.urlParam('currentFolder');

	// Adjust layout.
	setDimensions();
	$(window).resize(setDimensions);

	// Provides support for adjustible columns.
	$('#splitter').splitter({
		initA: 200
	});

	// cosmetic tweak for buttons
	$('button').wrapInner('<span></span>');

	// Set initial view state.
	$('#fileinfo').data('view', 'grid');

	// Set buttons to switch between grid and list views.
	$('#list').click(function(){
		$(this).addClass('ON');
		$('#grid').removeClass('ON');
		$('#fileinfo').data('view', 'list');
		getFolderInfo($('#currentpath').val());
	});

	$('#grid').click(function(){
		$(this).addClass('ON');
		$('#list').removeClass('ON');
		$('#fileinfo').data('view', 'grid');
		getFolderInfo($('#currentpath').val());
	});

	// Provide initial values for upload form, status, etc.
	setUploader(fileRoot);

	$('#uploader').attr('action', fileConnector);

	$('#uploader').ajaxForm({
		target: '#uploadresponse',
		success: function(result){
			var data = eval('(' + $('#uploadresponse').find('textarea').text() + ')');

			if(data['Code'] == 0)
			{
				addNode(data['Path'], data['Name'], "file");
			} else
			{
				$.prompt(data['Error']);
			}
		}
	});

	// Creates file tree.
	startFileTree();

	// show files of the current dir as a grid
	$('#grid').click();
});

function startFileTree()
{
	$('#filetree').fileTree(
		{
			root: fileRoot,
			script: treeConnector,
			multiFolder: false,
			folderCallback: function(path){ getFolderInfo(path); },
			after: setFileTreeEvents,
			expandSpeed: 300,
			collapseSpeed: 200
		}, function(file){
			getFileInfo(file);
		}
	);
}

function reloadFiletree()
{
	// erase the file tree
	$("#filetree").attr('class', '').html('');
	// reload the file tree now
	startFileTree();
}