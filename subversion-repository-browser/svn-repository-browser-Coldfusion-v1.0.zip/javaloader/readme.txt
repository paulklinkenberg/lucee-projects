JavaLoader v1.0 Beta 2
Author: Mark Mandel
Date: 20 January 2010

Documentation can now be found at:
http://www.compoundtheory.com/javaloader/docs/